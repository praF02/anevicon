# Examples
This is the examples directory for the Anevicon Core Library where you can understand general concepts by looking the code. To execute necessary examples type this command:

```bash
$ cargo run --example <NAME>...
```